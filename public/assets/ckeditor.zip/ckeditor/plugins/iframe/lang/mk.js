﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'mk', {
	border: 'Show frame border', // MISSING
	noUrl: 'Please type the iframe URL', // MISSING
	scrolling: 'Enable scrollbars', // MISSING
	title: 'IFrame Properties', // MISSING
	toolbar: 'IFrame' // MISSING
} );
