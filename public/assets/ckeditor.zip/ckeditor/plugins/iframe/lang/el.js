﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'el', {
	border: 'Προβολή περιγράμματος πλαισίου',
	noUrl: 'Παρακαλούμε εισάγεται το URL του iframe',
	scrolling: 'Ενεργοποίηση μπαρών κύλισης',
	title: 'Ιδιότητες IFrame',
	toolbar: 'IFrame'
} );
