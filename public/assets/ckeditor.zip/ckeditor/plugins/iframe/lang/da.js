﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'da', {
	border: 'Vis kant på rammen',
	noUrl: 'Venligst indsæt URL på iframen',
	scrolling: 'Aktiver scrollbars',
	title: 'Iframe egenskaber',
	toolbar: 'Iframe'
} );
